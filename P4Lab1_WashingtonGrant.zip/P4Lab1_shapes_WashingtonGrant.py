import turtle


wn = turtle.Screen()
leader = turtle.Turtle()
for moves in range(4):
    leader.forward(100)
    leader.right(90)


leader.color("blue")
for moves in range(3):
    leader.forward(100)
    leader.right(120)
    leader.forward(100)
    
wn.exitonclick()

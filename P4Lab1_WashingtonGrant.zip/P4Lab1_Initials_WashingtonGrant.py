import turtle

screen = turtle.Screen()
leader = turtle.Turtle()
leader.color('red')
leader.pensize(10)
# letter G commands

leader.left(180)
leader.forward(100)
leader.left(90)
leader.forward(100)
leader.left(90)
leader.forward(100)
leader.left(90)
leader.forward(50)
leader.left(90)
leader.forward(75)

# sets turtle in the correct position for next letter
leader.up()
leader.left(180)
leader.forward(100)
leader.left(90)
leader.forward(50)
leader.right(155)
leader.down()

#letter W commands
leader.forward(110)
leader.left(135)
leader.forward(110)
leader.right(135)
leader.forward(110)
leader.left(135)
leader.forward(110)

screen.exitonclick()
